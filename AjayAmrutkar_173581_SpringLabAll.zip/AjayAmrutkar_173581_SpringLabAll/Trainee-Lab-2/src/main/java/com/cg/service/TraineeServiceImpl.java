package com.cg.service;

public class TraineeServiceImpl {

}
