package com.cg.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entity.Trainee;
import com.cg.entity.login;
import com.cg.repo.ITraineeRepo;

@Scope("session")
@Controller
public class TraineeController {

	@Autowired
	private ITraineeRepo repo;

	private ArrayList<String> traineeLocation;
	private ArrayList<String> domain;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale loc, Model m) {

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, loc);

		String formattedDate = dateFormat.format(date);

		m.addAttribute("serverTime", formattedDate);

		return "index";
	}

	@RequestMapping(value = "/showLogin")
	public String prepareLogin(Model model) {
		System.out.println("In prepareLogin() method");
		model.addAttribute("login", new login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(login l, Model s) throws Exception {
		// Logic to validate userName and password against database
		if (l.getUserName().contains("ajay@gmail.com") && l.getPassword().contains("4441")) {

			return "loginSuccess";
		} else {

			return "login";
		}
	}

	@RequestMapping(value = "/register")
	public String addTrainee(Model model) {
		System.out.println("In prepareRegister() method");

		domain = new ArrayList<String>();

		domain.add("JEE");
		domain.add("Mainframe");
		domain.add(".Net");
		domain.add("Angular");

		traineeLocation = new ArrayList<String>();

		traineeLocation.add("Pune");
		traineeLocation.add("Mumbai");
		traineeLocation.add("Chennai");
		traineeLocation.add("Noida");

		model.addAttribute("traineeLocation", traineeLocation);
		model.addAttribute("domain", domain);

		model.addAttribute("user", new Trainee());
		return "register";
	}

	@RequestMapping(value = "saveTrainee")
	public String saveTrainee(@ModelAttribute("user") Trainee trainee, Model model) {
		System.out.println("In prepareAdd() method");

		model.addAttribute("register", new Trainee());

		repo.save(trainee);

		model.addAttribute("successMsg", "successfully saved trainee");
		return "loginSuccess";

	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return null;

	}

	@RequestMapping(value = "/findTrainee")
	public String findTrainee(@ModelAttribute("findTrainee") Trainee trainee, int id, Model model) {

		model.addAttribute("findTrainee", new Trainee());

		return "findTrainee";
	}
}
