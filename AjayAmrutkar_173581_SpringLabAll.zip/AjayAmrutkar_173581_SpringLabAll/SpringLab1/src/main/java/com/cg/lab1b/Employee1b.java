package com.cg.lab1b;

public class Employee1b {

	int empAge;
	int empId;
	String empName;
	Double empSalary;
	Sbu1b businessUnit;

	public Sbu1b getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(Sbu1b businessUnit) {
		this.businessUnit = businessUnit;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empAge=" + empAge + ", empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary
				+ "]\n";
	}

}