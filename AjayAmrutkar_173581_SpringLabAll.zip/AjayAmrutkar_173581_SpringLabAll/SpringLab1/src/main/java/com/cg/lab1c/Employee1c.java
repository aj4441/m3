package com.cg.lab1c;

public class Employee1c {

	int empId;
	int empAge;
	String EmpName;
	Double empsalary;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public Double getEmpsalary() {
		return empsalary;
	}

	public void setEmpsalary(Double empsalary) {
		this.empsalary = empsalary;
	}

	@Override
	public String toString() {
		return "Employee1c [empId=" + empId + ", empAge=" + empAge + ", EmpName=" + EmpName + ", empsalary=" + empsalary
				+ "]\n";
	}

}
