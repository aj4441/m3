package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1c.Employee1c;
import com.cg.lab1c.Sbu1c;

public class TestEmployeeLab1c {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("employeelab1c.xml");

		Sbu1c sbu = (Sbu1c) context.getBean("sbu");

		System.out.println(sbu);
	}

}
