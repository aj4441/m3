package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1b.Employee1b;

public class TestEmployeelab1b {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeelab1b.xml");
		Employee1b emp = (Employee1b) ctx.getBean("emp");
		System.out.println(emp);
		System.out.println(emp.getBusinessUnit());
	}

}
