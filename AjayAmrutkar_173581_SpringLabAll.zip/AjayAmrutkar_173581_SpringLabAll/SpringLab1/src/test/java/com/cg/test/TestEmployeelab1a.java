package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1a.Employee1a;

public class TestEmployeelab1a {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeelab1a.xml");
		Employee1a emp = (Employee1a) ctx.getBean("employee");
		System.out.println(emp);
	}

}
