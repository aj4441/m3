package com.cg.test;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1d.Employee1d;
import com.cg.lab1d.Sbu1d;

public class TestEmployeeLab1d {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("employeelab1d.xml");
		Employee1d employee = (Employee1d) context.getBean("employee1");

		Scanner input = new Scanner(System.in);
		int choice;
		System.out.println("Enter Employee ID:");
		choice = input.nextInt();

		if (choice == employee.getEmpId()) {
			System.out.println(employee);
		} else {
			System.out.println("Employee not found");
		}

	}
}
