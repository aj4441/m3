package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.IProductRepo;

@Service("service")
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo repo;

	@Override
	public Product saveProduct(Product product) {
		repo.save(product);
		return product;
	}

	@Transactional
	@Override
	public Iterable<Product> getAllproducts() {
		return repo.findAll();
	}

}
