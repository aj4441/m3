package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	private IProductService service;

	@PostMapping(path = "/addproducts", consumes = "application/json")
	public Product insertProduct(@RequestBody Product product) {
		return service.saveProduct(product);
	}

	@GetMapping(path = "/products")
	public Iterable<Product> getAllProducts() {
		return service.getAllproducts();
	}

	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })
	public String showError() {
		return "Id already exists";
	}

}
