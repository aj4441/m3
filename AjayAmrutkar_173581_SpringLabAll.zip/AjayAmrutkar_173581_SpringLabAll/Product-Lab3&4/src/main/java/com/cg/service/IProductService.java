package com.cg.service;

import com.cg.entity.Product;

public interface IProductService {

	Product saveProduct(Product product);
	
	Iterable<Product> getAllproducts();

}
