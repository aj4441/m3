package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import com.capstore.entity.Cart;

public interface CartService {

	void saveCart(Cart c);

	Iterable<Cart> getAll2();

	void addToCart(int cartId, int prodId);

	Cart getcartById(int id);

}
