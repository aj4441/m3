package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import com.capstore.entity.Customer;

public interface CustomerService {

	void saveCustomer(Customer c);

	Iterable<Customer> getAll1();

	public String deleteCustomer1(int id);

	Customer getCustomer(int id);
}
