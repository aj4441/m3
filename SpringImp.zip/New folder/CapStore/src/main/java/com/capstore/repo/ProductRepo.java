package com.capstore.repo;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.data.repository.CrudRepository;

import com.capstore.entity.Product;


public interface ProductRepo extends CrudRepository<Product, Integer>{

}
