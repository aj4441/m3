package com.cg.service;

import com.cg.entity.Album;

public interface AlbumService {

	Album findAlbumByArtist(String name);

	void saveAlbum(Album a);

	Album get(int id);

	Iterable<Album> getAll();

	public String deleteAlbum(int id);

	public Album update(Album a, int id);

}
