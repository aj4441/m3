package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;

@Repository
@Transactional
public class AlbumServiceImpl implements AlbumService {

	@Autowired
	private AlbumRepo repo;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveAlbum(Album a) {
		repo.save(a);
	}

	@Transactional
	public Iterable<Album> getAll() {
		return repo.findAll();
	}

	@Transactional
	public String deleteAlbum(int id) {
		Album a1 = repo.findById(id).get();
		repo.delete(a1);
		return "Delete Successfully";
	}

	@Transactional
	public Album update(Album a, int id) {
		a.setId(id);
		repo.save(a);
		return a;
	}

	@Override
	public Album findAlbumByArtist(String name) {
		return repo.findByArtist(name);
	}

	@Transactional(propagation = Propagation.SUPPORTS)
	public Album get(int id) {
		return repo.findById(id).get();
	}

}
