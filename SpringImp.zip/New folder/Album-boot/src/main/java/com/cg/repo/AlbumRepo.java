package com.cg.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Album;

public interface AlbumRepo extends CrudRepository<Album, Integer> {
	
	Album findByArtist(String name);
	

}
