package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Employee;

//this is an IProductRepo interface

public interface IProductRepo extends CrudRepository<Employee, Integer> {
	
	Employee findBydeptName(String deptName);
	

}
