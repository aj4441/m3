package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Employee;
import com.cg.repo.IProductRepo;

@Repository
@Transactional
public class ProductServiceImpl implements IProductService { // this is an product class

	@Autowired
	private IProductRepo repo;

	@Override

	// to save employee

	public Employee saveEmployee(Employee employee) {

		repo.save(employee);
		return employee;
	}

	@Override

	// get employee by id

	public Employee getEmployeeById(int empid) {

		return repo.findById(empid).get();
	}

	@Override

	// get all employees

	public Iterable<Employee> getAllEmployees() {

		return repo.findAll();
	}

	@Override

	// Update employee

	public Employee updateEmployee(Employee employee, int empid) {
		employee.setEmpid(empid);
		repo.save(employee);
		return employee;
	}

	@Override

	// delete method

	public String deleteEmployee(int empid) {
		repo.deleteById(empid);
		// return message
		return "Employee deleted successfully";
	}

	@Override

	// find method by deptname

	public Employee findBydeptName(String deptName) {
		return repo.findBydeptName(deptName);
	}

}
