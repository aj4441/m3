package com.cg.service;

import com.cg.entity.Employee;

//this is an product interface

public interface IProductService {

	Employee saveEmployee(Employee employee);

	Employee getEmployeeById(int empid);

	Iterable<Employee> getAllEmployees();

	Employee updateEmployee(Employee employee, int empid);

	public String deleteEmployee(int empid);

	Employee findBydeptName(String deptName);

}
