package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	private IProductService service;

	@PostMapping(path = "/createemployees", consumes = "application/json")
	public Employee insertCustomer(@RequestBody Employee employee) {
		return service.saveEmployee(employee);
	}

	@GetMapping(path = "/employees")
	public Iterable<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	@PutMapping("/updateemployees/{empid}")
	public Employee updateCustomer(@PathVariable int empid, @RequestBody Employee employee) {
		return service.updateEmployee(employee, empid);
	}

	@DeleteMapping("/deleteemployees/{empid}")
	public String deleteCustomer(@PathVariable int empid) {

		return service.deleteEmployee(empid);

	}

	@GetMapping(path = "/employees/{empid}", produces = "application/json")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int empid) {
		try {
			Employee emp = service.getEmployeeById(empid);
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("Employee id not found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/employees/{deptName}")
	public ResponseEntity<Employee> getEmployeeByName(@PathVariable String deptName) {
		try {
			Employee employee = service.findBydeptName(deptName);
			return new ResponseEntity<Employee>(employee, HttpStatus.OK);
		} catch (NoSuchElementException E) {
			return new ResponseEntity("Department name not found", HttpStatus.NOT_FOUND);
		}
	}

}
